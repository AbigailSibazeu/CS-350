import RPi.GPIO as GPIO
import serial
import time

# Set up GPIO
GPIO.setmode(GPIO.BCM)
GPIO.setup(18, GPIO.OUT)

# Set up serial communication
ser = serial.Serial('/dev/ttyS0', 9600, timeout=1)
ser.flush()

try:
    while True:
        if ser.in_waiting > 0:
            line = ser.readline().decode('utf-8').rstrip()
            print(f"Received: {line}")
            
            # Handle incoming commands
            if line == "ON":
                GPIO.output(18, GPIO.HIGH)
                ser.write("LED is ON\n".encode('utf-8'))
            elif line == "OFF":
                GPIO.output(18, GPIO.LOW)
                ser.write("LED is OFF\n".encode('utf-8'))
            elif line in ["EXIT", "QUIT"]:
                ser.write("Exiting...\n".encode('utf-8'))
                break

except KeyboardInterrupt:
    pass

finally:
    # Clean up GPIO
    GPIO.cleanup()
    ser.close()