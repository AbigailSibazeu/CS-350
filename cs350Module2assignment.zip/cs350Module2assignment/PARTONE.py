import RPi.GPIO as GPIO
import time

# Set the GPIO mode
GPIO.setmode(GPIO.BCM)

# Set up GPIO line 18 for PWM
GPIO.setup(18, GPIO.OUT)

# Create a PWM instance on GPIO line 18 with a frequency of 60 Hz
pwm18 = GPIO.PWM(18, 60)

try:
    # Start the PWM instance on GPIO line 18 with 0% duty cycle
    pwm18.start(0)

    while True:
        # Loop from 0 to 100 in increments of 5, and update the duty cycle
        for dutyCycle in range(0, 101, 5):
            pwm18.ChangeDutyCycle(dutyCycle)
            time.sleep(0.1)

        # Loop from 100 to 0 in increments of -5, and update the duty cycle
        for dutyCycle in range(100, -1, -5):
            pwm18.ChangeDutyCycle(dutyCycle)
            time.sleep(0.1)

except KeyboardInterrupt:
    # Catch the keyboard interrupt and clean up
    pass

finally:
    # Stop the PWM instance on GPIO line 18
    pwm18.stop()
    GPIO.cleanup()